# Changelog

## 0.3.0 — Revival (unreleased)

> **Back from the dead (2026-10-05).** The 2026-10-01 discontinuation was about the
> retired short-circuit *bridge* in dsh-thinking-levels — the official llm-pi-ai compat
> face replaced it for basic wire fixes. This revival is a different deal: the transport
> comes back as a **feature-bearing takeover** (multimodal true-send, modality gate,
> prompt-source seam) that pi-ai cannot offer, with dsh-thinking-levels' takeover gating
> reading this plugin's judgment. The 2026-10-01 notice below is historical.

### Revival — transport takeover, modernized

- **Short-circuit listener, dual-flag**: `llm/stream` with `{ prepend: true, global: true }`.
  The old build registered fiber-locally and never saw LlmRuntime-originated waterfalls on
  current hosts; `global` crosses the fiber boundary. Takeover short-circuits pi-ai
  (`adapter.stream` without `next()`); anything else passes through untouched.
- **Judgment, single source of truth**: `enabled && (manual providers ∪ auto-identified)`
  where auto-identified = custom openai-completions gateway AND thinking declared — the
  identification functions are a same-origin port of dsh-thinking-levels' `takeover-sync.ts`
  (both repos' tests lock the semantics). The switch and manual list live in this plugin's
  own settings section (`.volatile()` — runtime-editable, host-generated form); the
  data plane stays in llm-pi-ai, read per request through `settings.describe()` — the
  0.1.7+ read channel (the old `settings.get(ns)` / `settings.register` faces no longer
  exist on any supported host, which is what killed the original architecture).
- **Multimodal true-send**: the short-circuit consumes the waterfall BEFORE the host
  projects file blocks to text handles, so image / audio / video / PDF blocks arrive
  structural and are encoded (`image_url` / `input_audio` / `video_url` / OpenAI `file`
  data-URI parts) from attachment-service bytes (`readImage` / `readFileStream`), with a
  20 MB inline cap on video. No host patches, no file-handle reconstruction.
- **Modality hard gate**: undeclared modalities are refused BEFORE send
  (`INVALID_REQUEST`, naming the modality) — silent loss is replaced by an explicit
  refusal on taken-over routes. One-shot calls (`session-title`) strip media and never think.
- **The `llmOpenaiCompletions` prompt-source seam** (contract in AGENTS.md, mirroring
  dsh-llm-mimo's llmMimo): `listHostedModels()` + `registerPromptSource()` let a
  dsh-promptbook-class consumer replace the actual system prompt and tool descriptions
  per (provider, model), with cache-safe determinism and a no-source passthrough.
- **Credentials service**: `apiKeyEnv` resolves through `credentials.resolve(credentialRef(…))`
  with launch-environment fallback and a loud `MISSING_CREDENTIAL` — no more bare
  `process.env`.
- **Host lines**: FULL 15-rc enum (0.1.0-rc.2 … 0.2.0-rc.2) at all three gate points (engines,
  dsh.plugin.json, peers) — cross-line ranges are a semver false claim. Version
  conditionality in code: settings dual read channel (describe() on 0.1.7+, get(ns)
  before), legacy own-section registration (≤ 0.1.6, so the namespace stays visible to
  dsh-thinking-levels), ToolCallId/CallId import shim (0.1.0/0.1.1 lines),
  credentials → launch-environment → process.env resolution chain; `ToolCallId` import fixed for the 0.2.0 line; serializer
  handles both message shapes (0.1.x user-embedded tool results and 0.2.0 `role: 'tool'`
  messages).

### 2026-10-01 — Delisted / Discontinued (historical)

- **This project was discontinued and delisted from the maintained plugin set**:
  `dsh-thinking-levels` no longer needed it, so it was no longer maintained. npm stayed
  at **0.1.0** (published 2026-08-29); the local 0.2.0 line (vision / image input) was
  never published. Superseded by the 0.3.0 revival above.


The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-08-30

### 🎉 Major Feature — Vision/Image Input (major capability update, not a long-tail fix)

> A model that declares vision capability in its config (`input` contains `image`, written by the
> dsh-thinking-levels capability card as `['text','image']`) can now **receive user-uploaded images —
> single or multiple** — on this adapter. This closes the previous hard `UNSUPPORTED_CONTENT` ceiling
> and enables true vision workflows on custom OpenAI-completions gateways (vLLM Qwen-VL / LM Studio).

### Added
- **Vision-model image serialization**: user `image` content blocks are rendered as OpenAI-compatible
  multi-part `content` arrays with `image_url` data-URI parts (`data:<mediaType>;base64,<…>`),
  preserving **multi-image count and order** and interleaving text parts in the source order.
- **Attachment-aware byte resolution**: image bytes are resolved at runtime through an injected,
  lazily-resolved attachment store (`readImage` → base64), never during plugin apply.
- **Non-vision models still reject loudly**: a model that does **not** declare image input keeps
  throwing `UNSUPPORTED_CONTENT` on images — nothing is silently dropped.

### Breaking (internal only)
- `serializeMessages` / `serializeRequest` are now **async** and take an optional image source;
  `OpenAiCompletionsAdapter` gained a lazy attachment-store lookup parameter. No external callers.

## [0.1.0] - 2025-01-01

### Added
- OpenAI-completions-compatible adapter for custom gateways (vLLM / LM Studio / self-hosted proxies)
- `system` role always maps to `role: "system"` — eliminates `Unexpected message role` 400 on custom gateways
- Thinking driven by `compat.thinkingFormat` (qwen / qwen-chat-template / effort-capable modes)
- `</think>` content split on receive side — thinking text extracted to reasoning block
- Configuration in llm-pi-ai settings section
- Settings spec and takeover control spec documentation
